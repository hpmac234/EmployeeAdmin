﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EmployeeAdmin.Models
{
    public class Manager: SalariedEmployee
    {
        public string Catergory = "Manager";
        public float AnnualVacationDays = 30;
        public string SalariedOrHourly = "Salaried";
    }
}
