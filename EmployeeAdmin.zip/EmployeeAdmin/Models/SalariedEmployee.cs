﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EmployeeAdmin.Models
{
    public class SalariedEmployee : Employee
    {
        public string Catergory = "Salaried";
        public float AnnualVacationDays = 15;
        public string SalariedOrHourly = "Salaried";
    }
}
