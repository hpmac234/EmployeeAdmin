﻿using System.IO;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;


namespace EmployeeAdmin.Models
{
    public class Employee : IEmployee
    {
        public int Id { get; set; }
        public string Name { get; set; }
        //public string Catergory { get; set; }

        private string _catergory;

        [Display(Name = "Catergory")]
        public string Catergory
        {
            get { return _catergory; }
            set { 
                switch (value)
                {
                    case "Hourly":
                        AnnualVacationDays = 10;
                        SalariedOrHourly = "Hourly";
                        break;
                    case "Salaried":
                        AnnualVacationDays = 15;
                        SalariedOrHourly = "Salaried";
                        break;
                    case "Manager":
                        AnnualVacationDays = 30;
                        SalariedOrHourly = "Salaried";
                        break;
                }                
                
                _catergory = value; }
        }

        public string SalariedOrHourly { get; set; }

        public float AnnualVacationDays { get; set; }

        private const int _annualWorkdays = 260;

        public float AccummulatedVacations { get; set; } = 0; //>0, cannot write externally

        [Display(Name = "Number Of Days Worked")]
        [Range(0, 260, ErrorMessage = "Enter number between 0 to 260")]
        public int NumberOfDaysWorked { get; set; } = 0;

        [Range(0, 260, ErrorMessage = "Enter a number")]
        //[RegularExpression(@"[\d]", ErrorMessage = "VacationDaysToTake needs to be number.")]
        public float VacationDaysToTake { get; set; } = 0;


        public Employee()
        {

        }


        public void Work()
        {
            if (NumberOfDaysWorked >= 0 && NumberOfDaysWorked <= _annualWorkdays)
            {

                AccummulatedVacations = AnnualVacationDays * NumberOfDaysWorked / _annualWorkdays;
            }
            else
            {
                //return error "must be a number between 0 and 260";
            }
            //NumberOfDaysWorked = 0;
        }

        public void TakeVacation()
        {
            if (VacationDaysToTake > AccummulatedVacations)
            {
                //return error "You cannot take vacations more than accumulated";
            }
            AccummulatedVacations -= VacationDaysToTake;
            //VacationDaysToTake = 0;
        }

    }
}