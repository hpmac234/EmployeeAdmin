﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EmployeeAdmin.Models
{
    public class HourlyEmployee : Employee
    {
        public string Catergory = "Hourly";
        public float AnnualVacationDays = 10;
        public string SalariedOrHourly = "Hourly";
    }
}
