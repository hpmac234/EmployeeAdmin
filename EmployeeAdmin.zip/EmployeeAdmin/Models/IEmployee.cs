﻿using System.ComponentModel;

public interface IEmployee
{
    public void Work();

    public void TakeVacation();

}