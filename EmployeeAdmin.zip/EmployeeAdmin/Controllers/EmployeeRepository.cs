﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using EmployeeAdmin.Models;

namespace EmployeeAdmin.Controllers
{
    public static class EmployeeRepository 
    {
        private static List<Employee> _employeeList = new List<Employee>()
            {
            new Employee() { Id = 1, Name = "Mary",  Catergory="Hourly" },
            new Employee() { Id = 2, Name = "Grace",  Catergory="Hourly"},
            new Employee() { Id = 3, Name = "Eric",  Catergory="Hourly"},
            new Employee() { Id = 4, Name = "Bradon",  Catergory="Hourly"},
            new Employee() { Id = 5, Name = "Eve",  Catergory="Hourly"},
            new Employee() { Id = 6, Name = "Summer",  Catergory="Hourly"},
            new Employee() { Id = 7, Name = "Fall",  Catergory="Hourly"},
            new Employee() { Id = 8, Name = "Spring",  Catergory="Hourly"},
            new Employee() { Id = 9, Name = "Henry",  Catergory="Hourly"},
            new Employee() { Id = 10, Name = "Gary",  Catergory="Hourly"},

            //new Employee() { Id = 11, Name = "Larry",  Catergory="Manager", AnnualVacationDays = 30, AccummulatedVacations =0 },

            new Employee() { Id = 11, Name = "A",  Catergory="Salaried" },
            new Employee() { Id = 12, Name = "B",  Catergory="Salaried"},
            new Employee() { Id = 13, Name = "C",  Catergory="Salaried"},
            new Employee() { Id = 14, Name = "Y",  Catergory="Salaried"},
            new Employee() { Id = 15, Name = "G",  Catergory="Salaried"},
            new Employee() { Id = 16, Name = "HH",  Catergory="Salaried"},
            new Employee() { Id = 17, Name = "II",  Catergory="Salaried"},
            new Employee() { Id = 18, Name = "AAA",  Catergory="Salaried"},
            new Employee() { Id = 19, Name = "DDD",  Catergory="Salaried"},
            new Employee() { Id = 20, Name = "RRR",  Catergory="Salaried"},

            new Employee() { Id = 21, Name = "A1",  Catergory="Manager" },
            new Employee() { Id = 22, Name = "A4",  Catergory="Manager"},
            new Employee() { Id = 23, Name = "A3",  Catergory="Manager"},
            new Employee() { Id = 24, Name = "A7",  Catergory="Manager"},
            new Employee() { Id = 25, Name = "A0",  Catergory="Manager"},
            new Employee() { Id = 26, Name = "A9",  Catergory="Manager"},
            new Employee() { Id = 27, Name = "A12",  Catergory="Manager"},
            new Employee() { Id = 28, Name = "A8",  Catergory="Manager"},
            new Employee() { Id = 29, Name = "A33",  Catergory="Manager"},
            new Employee() { Id = 30, Name = "A55",  Catergory="Manager"}
            };

        public static IEnumerable<Employee> GetAllEmployees()
        {
            return _employeeList.ToList().OrderBy(x => x.Name).OrderBy(x => x.Catergory);
        }

        public static Employee GetEmployee(int? Id)
        {
            return _employeeList.FirstOrDefault(e =>e.Id == Id);
        }

        public static void AddEmployee(Employee employee)
        {
            int maxId = 0;
            foreach (var person in _employeeList)
            {
                if (person.Id > maxId)
                    maxId = person.Id;
            }
            employee.Id = maxId + 1;
            _employeeList.Add(employee);
        }

        public static void RemoveEmployee(int id)
        {
            _employeeList.Remove(_employeeList.SingleOrDefault(e=>e.Id==id));
        }

    }

}
