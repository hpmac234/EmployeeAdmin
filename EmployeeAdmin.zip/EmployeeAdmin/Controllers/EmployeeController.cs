﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using EmployeeAdmin.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace EmployeeAdmin.Controllers
{
    public class EmployeeController : Controller
    {
        // GET: EmployeeController

        //private EmployeeRepository _repository = new EmployeeRepository();
        public ActionResult Index()
        {                        
            return View(EmployeeRepository.GetAllEmployees());
        }

        //AddOrEdit Get Method
        public IActionResult AddOrEdit(int? id)
        {
            ViewBag.PageName = id == null ? "Create Employee" : "Edit Employee";
            ViewBag.IsEdit = id == null ? false : true;
            if (id == null)
            {
                Employee employee = new Employee();
                return View(employee);
            }
            else
            {
                var employee = EmployeeRepository.GetEmployee(id);

                if (employee == null)
                {
                    return NotFound();
                }
                return View(employee);
            }
        }

        //AddOrEdit Post Method
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult AddOrEdit(int employeeId, [Bind("Id,Name,Catergory,AnnualVacationDays,AccummulatedVacations")] Employee employeeData)
        {
            bool IsEmployeeExist = false;
            
            Employee employee = EmployeeRepository.GetEmployee(employeeData.Id);

            if (employee != null)
            {
                IsEmployeeExist = true;
            }
            else
            {
                employee = new Employee();
            }

            if (ModelState.IsValid)
            {
                
                employee.Name = employeeData.Name;
                employee.AccummulatedVacations = employeeData.AccummulatedVacations;
                employee.Catergory = employeeData.Catergory;


                if (!IsEmployeeExist)
                {
                    switch(employeeData.Catergory)
                    {
                        case "Hourly": employee.AnnualVacationDays = 10; break;
                        case "Salaried": employee.AnnualVacationDays = 15; break;
                        case "Manager": employee.AnnualVacationDays = 30; break;
                    }
                    
                    EmployeeRepository.AddEmployee(employee);
                }
                        
                return RedirectToAction(nameof(Index));
            }
            return View(employeeData);
        }


        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }
            var employee = EmployeeRepository.GetEmployee(id);
            if (employee == null)
            {
                return NotFound();
            }
            return View(employee);
        }


        public IActionResult Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }
            var employee = EmployeeRepository.GetEmployee(id);

            return View(employee);
        }

        // POST: Employee/Delete/1
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Delete(int id)
        {
            var employee = EmployeeRepository.GetEmployee(id);
            EmployeeRepository.RemoveEmployee(id);
            return RedirectToAction(nameof(Index));
        }



        public ActionResult Work(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }
            var employee = EmployeeRepository.GetEmployee(id);
            if (employee == null)
            {
                return NotFound();
            }
            return View(employee);
        }

        //AddOrEdit Post Method
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Work(int employeeId, [Bind("Id,Name,NumberOfDaysWorked,AnnualVacationDays,AccummulatedVacations")] Employee employeeData)
        {
            bool IsEmployeeExist = false;

            Employee employee = EmployeeRepository.GetEmployee(employeeData.Id);

            if (employee != null)
            {
                IsEmployeeExist = true;

                if (ModelState.IsValid)
                {
                    employee.NumberOfDaysWorked = employeeData.NumberOfDaysWorked;
                    employee.Work();
                    return RedirectToAction(nameof(Index));
                }
            }
            return View(employeeData);
        }



        public ActionResult TakeVacation(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }
            var employee = EmployeeRepository.GetEmployee(id);
            if (employee == null)
            {
                return NotFound();
            }
            return View(employee);
        }

        //AddOrEdit Post Method
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult TakeVacation(int employeeId, [Bind("Id,Name,VacationDaysToTake,AnnualVacationDays,AccummulatedVacations")] Employee employeeData)
        {
            bool IsEmployeeExist = false;

            
            Employee employee = EmployeeRepository.GetEmployee(employeeData.Id);

            if (employeeData.VacationDaysToTake > employee.AccummulatedVacations)
            {
                ModelState.AddModelError("VacationDaysToTake", "VacationDaysToTake cannot exceed AccummulatedVacations ");
                return View(employeeData);
            }
            else 
            {
                if (employee != null)
                {
                    IsEmployeeExist = true;

                    if (ModelState.IsValid)
                    {
                        employee.VacationDaysToTake = employeeData.VacationDaysToTake;
                        employee.TakeVacation();
                        return RedirectToAction(nameof(Index));
                    }
                }
                return View(employeeData);
            }
            
        }




    }
}
